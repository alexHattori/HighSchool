Welcome to Space Shooters

In this retro arcade game, blast your way through different enemies and create your own
levels

In any menu state,

1)use the arrow keys and the enter key to make selections

In the game state, 

1)use the arrow keys to move
2)press space to shoot

In the level editor, 

1)type name and press enter
2)use the number keys to generate enemies
3)press space to save